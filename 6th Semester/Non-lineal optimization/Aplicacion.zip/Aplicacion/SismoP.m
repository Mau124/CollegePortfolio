clear all
%System Parameters
m1 = 100;
m2 = 100;
m3 = 100;
m4 = 100;

k1 = 5;
k2 = 5;
k3 = 5;
k4 = 5;

M = [m1 0 0 0; 0 m2 0 0; 0 0 m3 0; 0 0 0 m4];
K = [-(k1 + k2) k2 0 0; k2 -(k2 + k3) k3 0; 0 k3 -(k3+k4) k4; 0 0 k4 -k4];
A = inv(M)*K;
b = [1; 1; 1; 1];
B = [1; 1; 1; 1];

%Initial conditions
x0 = [0; 0; 0; 0];
dx0 = [0; 0; 0; 0];

%Parámetros del Sismo
E = 3;
T = 2;
f = 1/T;
omega = 2*pi*f;

% Constantes
const = [0 0 0 500];
K_u = 0.5;

% Valores para exosistema
w = .1;
alpha = 0;
L = 1;
exo_M = [0 1; -(alpha^2 + w^2) -2*alpha];
exo_0 = [1; -alpha];
exo_y = [1 0];

% Encontrar vector k_opt
%A_opt = [0 1 0 0 0 0 0 0; -(k1+k2)/m1 0 k2/m1 0 0 0 0 0; 0 0 0 1 0 0 0 0; k2/m2 0 -(k2+k3)/m2 0 k3/m2 0 0 0; 0 0 0 0 0 1 0 0; 0 0 k3/m3 0 -(k3+k4)/m3 0 k4/m3 0; 0 0 0 0 0 0 0 1; 0 0 0 0 k4/m4 0 -k4/m4 0];
A_opt = [zeros(4, 4) eye(4); A zeros(4, 4)];
B_opt = [0; 0; 0; 0; 1; 1; 1; 1];
% p = [(-1 + 0i) (-2 + 0i) (-3 + 0i) (-4 + 0i) (-5 + 0i) (-6 + 0i) (-7 + 0i) (-8 + 0i)];
% p = [-.1 -.2 -.3 -.4 -.5 -.6 -.7 -.8];
p = [-.1 -.2 -.3 -.4 -.5 -.6 -.7 -.8];
k_opt = place(A_opt, B_opt, p);
%k_opt = [];
%k_opt = acker(A_opt, B_opt, p);
%k_opt = [2 -2 2 -2 2 -2 2 -2];
%x0_opt = [0; 0; 0; 0; 0; 0; 0; 0];
x0_opt = [-4; 5; -3; 2; 10; -4; 3; 2];